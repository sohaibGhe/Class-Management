// Get the search input element and all the card containers
const searchInput = document.getElementById('searchInput');
const cards = document.querySelectorAll('.col-md-4'); // Each card container

// Function to filter the cards based on the search input
searchInput.addEventListener('input', function() {
  const searchTerm = searchInput.value.toLowerCase();
  
  // Loop through each card
  cards.forEach(function(card) {
    const className = card.querySelector('.nameList').textContent.toLowerCase();
    
    // Show or hide the card based on the search term
    if (className.includes(searchTerm)) {
      card.style.display = '';  // Show the card
    } else {
      card.style.display = 'none';  // Hide the card
    }
  });
});
