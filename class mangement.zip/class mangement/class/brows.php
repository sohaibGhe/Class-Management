<?php
include '../phps/db.php';
include '../phps/select.php';
session_start();
if (!isset($_SESSION['id_t'])){
  header("Location: ../loginpages/index.php");
    exit;
}
if (!isset($_GET['class_id'])) {
    header("Location: class.php");
}
$classid = $_GET['class_id'];
$class = getClass($classid, $conn);
$Groupes =getGroupes($classid,$conn) ;
if (isset($_POST['grbid'])) {
    $grbid = $_POST['grbid'];
    $students = getstudents($classid,$grbid,$conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Browse Class - <?= htmlspecialchars($class['Class_Name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@900&   family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;800;900&display=swap" rel="stylesheet">
    <link href="styles.css" rel="stylesheet">

</head>
<body>



<div class="container mt-4">
    <div class="row mb-4 ">
        <div class="col-md-8">
            <h2 class="class-title"><?= htmlspecialchars($class['Class_Name']) ?></h2>
        </div>
        <div class="col-md-4 text-end" >
            <strong>Subject:</strong> <?= htmlspecialchars($class['Subject']) ?><br>
            <strong>Schedule:</strong> <?= htmlspecialchars($class['Schedule']) ?>
        </div>
    </div>

    <div class="container mb-3">
        <div class="row mb-2">
            <div class="col pt-3">
                <h3 class="">Groups : </h3>
            </div>
            <div class="col-md-4 text-end">
              <button class="btn btn-primary mt-3" data-bs-toggle="modal" 
              data-bs-target="#addGroupModal">+ Add New group</button>

            </div>
        </div>
    </div>
<div class="container mb-5">
    <div class="row justify-content-center align-items-center g-2">
        <?php 
            foreach ($Groupes as $Groupe) {        
        ?>
        <div class="col">
            <form method="POST">
                <div class="d-flex justify-content-between align-items-center">
                    <input type="hidden" name="grbid" value="<?= $Groupe['id'] ?>">
                    <button type="submit" class="btn"><?= $Groupe['name'].' '.$Groupe['type'] ?></button>
                </div>
            </form>
        </div>
        <?php 
            } 
        ?>
    </div>
</div>

<?php if (isset($students)) {?>
    <div class="mb-2">
        <form action="../import_excel.php" method="POST" enctype="multipart/form-data">
            <label for="formFile" class="form-label">Upload Excel File:</label>
            <div class="d-flex align-items-center">
                <input type="hidden" name="grbid" value="<?= $grbid ?>">
                <input type="hidden" name="classid" value="<?= $classid ?>">
                <input class="form-control me-2" type="file" name="file" id="formFile" required>
                <button type="submit" name="upload" class="btn btn-primary">Upload</button>
            </div>
        </form>
    </div>

    <div class="container">
        <div class="row mb-2">
            <div class="col pt-3">
                <h3 class="">Student Information</h3>
            </div>
            <div class="col-md-4 text-end">
              <button class="btn btn-primary mt-3" data-bs-toggle="modal" 
              data-bs-target="#studentModal">+ Add New Student</button>

            </div>
        </div>
    </div>
    
    <!-- Students Table -->
   
    <table class="table table-bordered table-hover" id="myTable">
        <thead class="table-dark">
            <tr>
                <th>#</th>
                <th>ID</th>
                <th>Name</th>
                <th>Date of Birth</th>
                <th>Birthplace</th>
                <th>Email</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($students) {
                foreach ($students as $index => $student) {
                    echo "<tr>";
                    echo "<td>" . ($index + 1) . "</td>";
                    echo "<td>" . $student['id_Student'] . "</td>";
                    echo "<td>" . htmlspecialchars($student['name_F_L']) . "</td>";
                    echo "<td>" . htmlspecialchars($student['date_of_birth']) . "</td>";
                    echo "<td>" . htmlspecialchars($student['birthplace']) . "</td>";
                    echo "<td>" . htmlspecialchars($student['email']) . "</td>";
                    echo "<td>
                            <form method='POST' action='../phps/delete.php' style='display:inline;'>
                                <input type='hidden' name='student_id' value='" . htmlspecialchars($student['id_Student']) . "'>
                                <input type='hidden' name='class_id' value='" . htmlspecialchars($_GET['class_id']) . "'>
                                <button type='submit' class='btn btn-danger btn-sm'>Remove</button>
                            </form>
                          </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='6' class='text-center'>No students found</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <!-- Export Students to Excel -->
    <h3 class="mt-4">Export Student List to Excel</h3>
    <button id="exportBtn" class="btn btn-success mb-4">Export to Excel</button>
    <?php } ?>
</div>

<div class="modal fade" id="addGroupModal" tabindex="-1" aria-labelledby="addGroupModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addGroupModalLabel">Add New Group</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="../phps/inserts.php" method="post" id="addGroupForm">
          <div class="mb-3">
            <label for="groupName" class="form-label">Group Name</label>
            <input type="text" class="form-control" name="group_name" id="groupName" required>
          </div>
          <div class="mb-3">
            <label for="groupType" class="form-label">Group Type</label>
            <select class="form-select" name="group_type" id="groupType" required>
              <option value="TD">TD</option>
              <option value="TP">TP</option>
            </select>
          </div>
          <input type="hidden" name="classid" id="classid" value="<?= $_GET['class_id'] ?>">
          <button type="submit" class="btn btn-primary">Save Group</button>
        </form>
      </div>

    </div>
  </div>
</div>

<?php if (isset($students)) {?>
<div class="modal fade" id="studentModal" tabindex="-1" aria-labelledby="studentModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="studentModalLabel">Add New Student</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form action="../phps/inserts.php" method="post" id="studentForm">
            <div class="mb-3">
              <label for="studentName" class="form-label">Full Name</label>
              <input type="text" class="form-control" name="name_F_L" id="studentName" required>
            </div>
            <div class="mb-3">
              <label for="dob" class="form-label">Date of Birth</label>
              <input type="date" class="form-control" name="date_of_birth" id="dob" required>
            </div>
            <div class="mb-3">
              <label for="birthplace" class="form-label">Birthplace</label>
              <input type="text" class="form-control" name="birthplace" id="birthplace" required>
            </div>
            <div class="mb-3">
              <label for="email" class="form-label">Email Address</label>
              <input type="email" class="form-control" name="email" id="email" required>
              <input type="hidden" name="classid" id="classid" value="<?= $_GET['class_id'] ?>" >
              <input type="hidden" name="grbid" id="grbid" value="<?= $grbid ?>" >
            </div>
            <button type="submit" class="btn btn-primary">Save Student <?= $grbid ?></button>
          </form>
        </div>
      </div>
    </div>
</div>
<?php }?>


<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.4/xlsx.full.min.js"></script>
    <script>
        document.getElementById('exportBtn').addEventListener('click', function() {
            var wb = XLSX.utils.table_to_book(document.getElementById('myTable'), {sheet: "Sheet 1"});
            XLSX.writeFile(wb, '<?=$class['Class_Name']?>_Students_Liste.xlsx');
        });
    </script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>


</body>
</html>
