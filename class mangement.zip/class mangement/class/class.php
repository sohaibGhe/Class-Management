<?php 
include '../phps/db.php';
include '../phps/select.php';
session_start();
if (!isset($_SESSION['id_t'])){
  header("Location: ../loginpages/index.php");
    exit;
}
 $teacher_id = $_SESSION['id_t'] ;
$classes = getClasses($teacher_id,$conn) ;

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Class Management</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@900&   family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;800;900&display=swap" rel="stylesheet">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <div class="container my-4 px-5">
    <header class="d-flex justify-content-between align-items-center">
      <h1>Class Management</h1>
      <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#classModal">+ Add New Class</button>
    </header>

    <div class="mt-3">
      <input type="text" id="searchInput" class="form-control" placeholder="Search classes...">
    </div>

    <?php
$classes = getClasses($teacher_id,$conn) ;

?>

<section class="row mt-4" id="classList">
    <!-- Loop through each class and create a card for each one -->
    <?php foreach ($classes as $cls): ?>
        <div class="col-md-4 show">
            <div class="card p-3">
                <h5 class="card-title nameList"><?= htmlspecialchars($cls['Class_Name']) ?></h5>
                <p class="card-text">Subject: <?= htmlspecialchars($cls['Subject']) ?></p>
                <p class="card-text">Schedule: <?= htmlspecialchars($cls['Schedule']) ?></p>
                <div class="card-buttons">
                    <a  class="btn btn-warning btn-sm"
                    data-bs-toggle="modal" data-bs-target="#classModal">Edit</a>
                    <a href="../phps/delete.php?id=<?= $cls['id'] ?>"
                     class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this class?')">Delete</a>
                    <a href="brows.php?class_id=<?= $cls['id'] ?>" class="btn btn-success btn-sm">Browse</a>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</section>

  </div>

  <!-- Modal for Adding/Editing Classes -->
  <div class="modal fade" id="classModal" tabindex="-1" aria-labelledby="classModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="classModalLabel">Add New Class</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <form action="../phps/inserts.php" method="post" id="classForm">
            <div class="mb-3">
              <label for="className" class="form-label">Class Name</label>
              <input type="text" class="form-control" name="name" na required>
            </div>
            <div class="mb-3">
              <label for="classSubject" class="form-label">Subject</label>
              <input type="text" class="form-control" name="subject" required>
            </div>
            <div class="mb-3">
              <label for="classSchedule" class="form-label">Schedule</label>
              <input type="hidden" name="id_teacher" value="<?= $teacher_id ?>">
              <input type="text" class="form-control" name="schedule" placeholder="e.g., Mon & Wed, 10:00 AM - 11:30 AM" required>
            </div>
            <button type="submit" class="btn btn-primary">Save Class</button>
          </form>
        </div>
      </div>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="script.js"></script>
    

</body>
</html>
