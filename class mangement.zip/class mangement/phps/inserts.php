<?php
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['subject'])) {
        $name = $_POST['name'];
        $subject = $_POST['subject'];
        $schedule = $_POST['schedule'];
        $id_teacher = $_POST['id_teacher'];

        $sql = "INSERT INTO class (Class_Name, Subject, Schedule ,	id_teacher)
           VALUES ('$name', '$subject', '$schedule', '$id_teacher')";

        if ($conn->query($sql) === TRUE) {
            header("Location: ../class/class.php");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    if (isset($_POST['date_of_birth'])) {
        $name = $_POST['name_F_L'];
        $date_of_birth = $_POST['date_of_birth'];
        $birthplace = $_POST['birthplace'];
        $email = $_POST['email'];
        $classid= $_POST['classid'] ;
        $grbid = $_POST['grbid'] ;

        $sql = "INSERT INTO student (name_F_L,date_of_birth, birthplace, email , class_std, group_id)
         VALUES ('$name', '$date_of_birth', '$birthplace', '$email' , '$classid' , '$grbid')";

        if ($conn->query($sql) === TRUE) {
            header("Location: ../class/brows.php?class_id=$classid");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
    if (isset($_POST['group_name'])) {
        $name = $_POST['group_name'];
        $groupType = $_POST['group_type'];
        $classid= $_POST['classid'] ;

        $sql = "INSERT INTO `group` (name,type, class_id)
         VALUES ('$name', '$groupType','$classid')";

        if ($conn->query($sql) === TRUE) {
            header("Location: ../class/brows.php?class_id=$classid");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}
else{
header("Location: ../class/class.php");
}
$conn->close();
?>
