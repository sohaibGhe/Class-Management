<?php
include 'db.php';
include 'db.conn.php';

function getClasses($teacher_id , $conn){
    $sql = "SELECT * FROM class where id_teacher = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$teacher_id]);
    if ($stmt->rowCount() > 0) {
             $classes = $stmt->fetchAll();
             return $classes;
    }else {
            $classes = [];
            return $classes;
    }
}
function getClass($id,$conn){
    $sql = "SELECT * FROM class where id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$id]);
    if ($stmt->rowCount() > 0) {
             $class = $stmt->fetch();
             return $class;
    }else {
            $class = [];
            return $class;
    }
}
function getstudents($classid,$grbid,$conn){
    $sql = "SELECT * FROM student where class_std= ? AND group_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$classid,$grbid]);
    if ($stmt->rowCount() > 0) {
             $students = $stmt->fetchAll();
             return $students;
    }else {
            $students = [];
            return $students;
    }
}
function getGroupes($classid,$conn){
    $sql = "SELECT * FROM `group` where class_id= ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$classid]);
    if ($stmt->rowCount() > 0) {
             $groupes = $stmt->fetchAll();
             return $groupes;
    }else {
            $groupes = [];
            return $groupes;
    }
}


?>