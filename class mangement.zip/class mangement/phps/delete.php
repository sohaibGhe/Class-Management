<?php
include 'db.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "DELETE FROM class WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        header("Location: ../class/class.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
print_r($_POST);
if (isset($_POST['student_id'])) {
    $id = $_POST['student_id'];
    $class_id = $_POST['class_id'] ;
    $sql = "DELETE FROM student WHERE id_Student=$id";

    if ($conn->query($sql) === TRUE) {
        header("Location: ../class/brows.php?class_id=$class_id");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}



?>
