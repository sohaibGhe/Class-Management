<?php 
session_start();
if (!isset($_SESSION['id_t'])){
  header("Location: loginpages/index.php");
    exit;
}
if ($_SERVER["REQUEST_METHOD"] == "POST") {
session_unset(); 
session_destroy(); 
header("Location: loginpages/index.php");
exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Enseigne</title>
    <link href="styles.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300..900;1,300..900&display=swap" rel="stylesheet">  <style>
        body {
            font-family: 'Rubik', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            display: flex;
            flex-direction: column;
            background-image:url('GoOnlineTools-image-downloader.jpg') ;
            background-position: center;
            background-size: cover;
            }
        .img1{
            max-height: 400px;
            min-height: 400px;
            object-fit: cover;
        }

        .card{
            background-color: rgba(255, 255, 255, 0.44);
        }
        
    </style>
</head>
<body id="body">
   <div class="justify-content-center align-items-center " style="text-align: center; ">
       <h1 class="mt-4" style=" font-size: 50px; ">
        <sup class="p-3" style="background-color: rgba(255, 255, 255, 0.44);"></span> Welcome to ProfConnect</h1>
   </div>
      <div class="container-fuiled p-4">
        <div class="row justify-content-center align-items-center g-2">
          <div class="col">
              <div class="card" >
                <img src="images/austrian-national-library-A3FNnZ55bR8-unsplash.jpg" class="card-img-top img1" alt="...">
                <div class="card-body">
                  <h3 class="card-title">Class Management</h3>
                  <p class="card-text text-center">
                    <a class="btn btn-success" type="button" href="class/class.php">Brows</a>  
                  </p>
                </div>
              </div>
          </div>
          <div class="col">
              <div class="card">
                <img src="images/austrian-national-library-rCRvCeVEul4-unsplash.jpg" class="card-img-top img1" alt="...">
                <div class="card-body">
                  <h3 class="card-title">Student Management</h3>
                  <p class="card-text text-center">
                  <a class="btn btn-success" type="button" href="matrier.php">Brows</a>  
                  </p>
                </div>
              </div>
          </div>
          <div class="col">
            <div class="card">
              <img src="images/students-at-a-wall-looking-at-announcements-ca-1948-2J2C1RP-transformed.jpeg" class="card-img-top img1" alt="...">
              <div class="card-body">
                <h3 class="card-title">Announcement</h3>
                <p class="card-text text-center">
                <a class="btn btn-success" type="button" href="matrier.php">Brows</a>  
                </p>
              </div>
          </div>
        </div>
        <form  method="post">
          <button   class="btn btn-danger">
            log out
          </button>
        </form>
        

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
</body>
</html>