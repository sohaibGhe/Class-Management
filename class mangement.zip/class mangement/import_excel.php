<?php
require 'vendor/autoload.php'; // Include PhpSpreadsheet
include 'phps/db.conn.php'; // Database connection

use PhpOffice\PhpSpreadsheet\IOFactory;

$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); // Enable detailed error reporting

// Check if the form is submitted
if (isset($_POST['upload'])) {
    $classid =$_POST['classid'] ;
    $grbid =$_POST['grbid'] ;

    // Check if a file is uploaded
    if (isset($_FILES['file']['tmp_name'])) {
        $file = $_FILES['file']['tmp_name'];

        try {
            // Load the Excel file
            $spreadsheet = IOFactory::load($file);
            $sheet = $spreadsheet->getActiveSheet();

            // Loop through each row in the Excel sheet
            foreach ($sheet->getRowIterator() as $row) {
                $cellIterator = $row->getCellIterator();
                $cellIterator->setIterateOnlyExistingCells(false); // Iterate all cells

                $rowData = [];
                foreach ($cellIterator as $cell) {
                    $rowData[] = $cell->getFormattedValue();
                }

                // Debugging: Print row data (optional)
                print_r($rowData);
                echo '<br>';

                // Check if there are enough columns
                if (count($rowData) >= 4) { 
                    $sql = "INSERT INTO student (name_F_L , date_of_birth, birthplace, email, class_std, group_id) 
                            VALUES (?, ?, ?, ?, ?, ?)";
                    $stmt = $conn->prepare($sql);

                    // Check if the statement is prepared successfully
                    if (!$stmt) {
                        die("Error preparing SQL statement: " . implode(" ", $conn->errorInfo()));
                    }

                    // Execute the query
                    $stmt->execute([
                        $rowData[1], // name_F_L
                        $rowData[2], // date_of_birth
                        $rowData[3], // birthplace
                        $rowData[4], // email
                        $classid   ,
                        $grbid         // class_std
                    ]);
                }
            }

            header("Location: class/brows.php?class_id=$classid");

        } catch (Exception $e) {
            echo 'Error: ' . $e->getMessage();
        }
    } else {
        echo "Please upload a file.";
    }
}
?>
