<?php
include '../phps/db.conn.php';
session_start();
if (isset($_SESSION['id_t'])){
  header("Location: ../index.php");
    exit;
}
$messageAff='';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['pass'];
    $sql = "SELECT * FROM teacher WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    if ($user) {
        if (password_verify($password, $user['pass'])) {
            $_SESSION['id_t'] = $user['id_t'];
            header("Location: ../index.php");
            exit;
        } else {
            $messageAff = 'Incorrect password';
        }
    } else {
        $messageAff = 'Incorrect email address';
    }
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Login Enseigne</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
</head>
<body style="background-color: #666666;">
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				
			    <form class="login100-form validate-form"  method="post" id="loginForm">
                    <span class="login100-form-title p-b-43">
                        Se connecter <?= $messageAff ?>
                    </span>
                    <div class="wrap-input100 validate-input" data-validate="Valid email is required: ex@abc.xyz">
                        <input class="input100" type="text" name="email" value="<?= isset($email) ? $email : '' ?>">
                        <span class="focus-input100"></span>
                        <span class="label-input100">Email</span>
                    </div>
                    <div class="wrap-input100 validate-input" data-validate="Password is required">
                        <input class="input100" type="password" name="pass">
                        <span class="focus-input100"></span>
                        <span class="label-input100">Mot de passe</span>
                    </div>
                    <div class="container-login100-form-btn">
                        <button class="login100-form-btn" type="submit" name="login">
                            Se connecter
                        </button>
                    </div>
                </form>

                <form class="login100-form validate-form"action="regist.php" method="post" id="registerForm" style="display: none;">
                    <span class="login100-form-title p-b-43">
                        Create Account
                    </span>
                    <div class="wrap-input100 validate-input" data-validate="Teacher's name is required">
                        <input class="input100" type="text" name="name" required>
                        <span class="focus-input100"></span>
                        <span class="label-input100">Teacher's Name</span>
                    </div>
                    <div class="wrap-input100 validate-input" data-validate="Valid email is required: ex@abc.xyz">
                        <input class="input100" type="text" name="email" required>
                        <span class="focus-input100"></span>
                        <span class="label-input100">Email</span>
                    </div>
                    <div class="wrap-input100 validate-input" data-validate="Password is required">
                        <input class="input100" type="password" name="password" required>
                        <span class="focus-input100"></span>
                        <span class="label-input100">Password</span>
                    </div>
                    <div class="container-login100-form-btn">
                        <button class="login100-form-btn" type="submit" name="register">
                            Register
                        </button>
                    </div>
                </form>
				
				<div class="text-center p-t-10" style="position: absolute; top: 0; right: 0; z-index: 1000;">
					<button class="btn btn-primary" id="showRegisterFormBtn" style="display: block;">Create Account</button>
					<button class="btn btn-secondary" id="showLoginFormBtn" style="display: none;">Se connecter</button>
				</div>

				<div class="login100-more" style="background-image: url('images/kenny-eliason-1-aA2Fadydc-unsplash.jpg');">
				</div>
			</div>
		</div>
	</div>
	
	
	<script src="js/main.js"></script>
	<script>
        const showRegisterFormBtn = document.getElementById('showRegisterFormBtn');
        const showLoginFormBtn = document.getElementById('showLoginFormBtn');
        const loginForm = document.getElementById('loginForm');
        const registerForm = document.getElementById('registerForm');

        showRegisterFormBtn.addEventListener('click', function() {
            loginForm.style.display = 'none';
            registerForm.style.display = 'block';
            showRegisterFormBtn.style.display = 'none';
            showLoginFormBtn.style.display = 'block';
        });

        showLoginFormBtn.addEventListener('click', function() {
            registerForm.style.display = 'none';
            loginForm.style.display = 'block';
            showRegisterFormBtn.style.display = 'block';
            showLoginFormBtn.style.display = 'none';
        });
    </script>


</body>
</html>