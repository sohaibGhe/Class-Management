<?php
include '../phps/db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    
    $name = $conn->real_escape_string($name);
    $password = $conn->real_escape_string($password);
    $email = $conn->real_escape_string($email);
    
    $sql = "SELECT id_t FROM teacher WHERE email = '$email'";
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        echo "The email address is already in use. Please use a different one.";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO teacher (name, pass, email) VALUES ('$name', '$hashed_password', '$email')";
    
        if ($conn->query($sql) === TRUE) {
            header("Location: index.php");
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
        
}
else{
header("Location: ../class/class.php");
}
$conn->close();
?>
